# Calendario Técnico - Prebenjamín B

Aplicación de calendario para el cuerpo técnico del Prebenjamín B del Real Madrid.

## Credenciales de acceso

| Usuario | Contraseña | Rol |
|---------|------------|-----|
| `sergio` | `preb2026` | Segundo Entrenador |
| `raul` | `preb2026` | Primer Entrenador |

**Importante**: Cambia estas contraseñas antes del despliegue en producción editando el objeto `USERS` en index.html.

## Características

- **Calendario interactivo**: Vista mensual con eventos codificados por color
- **Importación de Excel**: Detecta automáticamente entrenamientos del Prebenjamín B
- **Notificaciones push**: Recordatorios antes de entrenamientos y partidos
- **Multi-usuario**: Login individual con datos compartidos
- **PWA**: Instalable en móvil/escritorio, funciona offline

## Despliegue en Vercel

### Opción 1: Vercel CLI (recomendado)

```bash
npm i -g vercel
cd prebenjamin-calendar
vercel --prod
```

### Opción 2: GitHub + Vercel

1. Sube esta carpeta a un repositorio de GitHub
2. Conecta el repo en vercel.com
3. Deploy automático

## Formato del Excel

La app busca patrones como "Prebenjamín B", "Pre-Benjamín B", etc. y extrae:
- Días de entrenamiento (Lunes, Martes, etc.)
- Horarios (formato HH:MM)
- Campos (Campo 8B, etc.)

## Sincronización entre dispositivos

Por defecto usa localStorage (cada dispositivo independiente). Para sincronización real:

1. Crea un proyecto en Supabase o Firebase
2. Reemplaza las funciones `saveEvents()`/`loadEvents()` con llamadas a la API
3. Configura las variables de entorno en Vercel

## Colores corporativos

Basados en la equipación 24/25:
- Blanco: #FFFFFF
- Dorado: #D4A853
- Negro: #1A1A1A
